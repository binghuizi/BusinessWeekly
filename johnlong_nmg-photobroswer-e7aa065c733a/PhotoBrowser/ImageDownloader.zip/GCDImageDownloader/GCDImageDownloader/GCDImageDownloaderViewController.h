//
//  GCDImageDownloaderViewController.h
//  GCDImageDownloader
//
//  Created by Slava on 5/22/11.
//  Copyright 2011 Alterplay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GCDImageDownloaderViewController : UIViewController {
    NSArray *_images;
}

@end
